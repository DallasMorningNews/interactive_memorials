# memorials
This is an embeddable map that accepts and displays submissions for memorials that would commemorate diversity in the state of Texas.
